-- Connect to database

--connect 'jdbc:derby://localhost:1527/petshopdb' user 'pet' password 'pet';

-- Data Dumps 

INSERT INTO IMAGE(IMG_NAME, IMG_DESC, IMG_LOCATION, IMG_TYPE, IMG_FILE_TYPE) VALUES ('CannedMilk','Food and Treats, Canned','img/canfood', 'P','jpg');
INSERT INTO IMAGE(IMG_NAME, IMG_DESC, IMG_LOCATION, IMG_TYPE, IMG_FILE_TYPE) VALUES ('calciummilkbone','Food and Treats, Dry','img/dryfood', 'P','jpg');
INSERT INTO IMAGE(IMG_NAME, IMG_DESC, IMG_LOCATION, IMG_TYPE, IMG_FILE_TYPE) VALUES ('royalcaninboxerjuniorrs','Food and Treats, Dry','img/dryfood', 'P','jpg');

 

INSERT INTO CATEGORY(CAT_NAME, CAT_DESC, CAT_CHILD_CODE, IMG_CODE) VALUES ('Food and Treats',	'All kind of foods for Dogs(petsgonut)',	0,	1);
INSERT INTO CATEGORY(CAT_NAME, CAT_DESC, CAT_CHILD_CODE, IMG_CODE) VALUES ('Dry Food',	'All',	1,	1);
INSERT INTO CATEGORY(CAT_NAME, CAT_DESC, CAT_CHILD_CODE, IMG_CODE) VALUES ('Wet Food',	'All',	1,	1);
INSERT INTO CATEGORY(CAT_NAME, CAT_DESC, CAT_CHILD_CODE, IMG_CODE) VALUES ('Canned Food',	'All',	1,	1);
INSERT INTO CATEGORY(CAT_NAME, CAT_DESC, CAT_CHILD_CODE, IMG_CODE) VALUES ('Doggy Treats',	'All',	1,	1);
INSERT INTO CATEGORY(CAT_NAME, CAT_DESC, CAT_CHILD_CODE, IMG_CODE) VALUES ('Doggy Biscuits',	'All',	1,	1);


INSERT INTO PRODUCT(PRD_NAME, PRD_DESC, PRD_PRICE, IMG_CODE, CAT_CODE)  VALUES ('Royal Canin Baby Dog Milk',  'Canned Food 400gm', 342, 1 ,4);
INSERT INTO PRODUCT(PRD_NAME, PRD_DESC, PRD_PRICE, IMG_CODE, CAT_CODE)  VALUES ('Royal Calcium Milk Bone',  'Dry Food 1400gm', 420, 2 ,2);
INSERT INTO PRODUCT(PRD_NAME, PRD_DESC, PRD_PRICE, IMG_CODE, CAT_CODE)  VALUES ('Royal Canin Boxer Juniorrs',  'Dry Food 200gm', 402, 3 , 2);

INSERT INTO USERS(USR_NAME, USR_PWD, USR_ALIAS, USR_TYPE, USR_MOBILE, USR_EMAIL, USR_ADDRESS) VALUES ('Rani Velu',  'welcome', 'ravelu', 'C' , 9538990123, 'rani.velu@capgemini.com', 'PSN, Cresent2, Bangalore, IN');
INSERT INTO USERS(USR_NAME, USR_PWD, USR_ALIAS, USR_TYPE, USR_MOBILE, USR_EMAIL, USR_ADDRESS) VALUES ('Rani Velu',  'welcome', 'ravelu1', 'C' , 9036197066, 'rani.velu@capgemini.com', 'PSN, Cresent2, Bangalore, IN');

COMMIT;