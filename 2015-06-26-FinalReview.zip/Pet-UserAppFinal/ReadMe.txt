REst ful APIS


http://localhost:8080/petuser/rest/user/find/ravelu

{"usrCode":1,"usrName":"Rani Velu","usrPwd":"welcome","usrAlias":"ravelu","usrType":"C","usrMobile":0,"usrEmail":"rani.velu@capgemini.com","usrAddress":"PSN, Cresent2, Bangalore, IN"}


http://localhost:8080/petadmin/rest/products

[{"prdCode":1,"prdName":"Royal Canin Baby Dog Milk","prdDesc":"Canned Food 400gm","prdPrice":342,"imgCode":1,"catCode":4},{"prdCode":2,"prdName":"Royal Calcium Milk Bone","prdDesc":"Dry Food 1400gm","prdPrice":420,"imgCode":2,"catCode":2},{"prdCode":3,"prdName":"Royal Canin Boxer Juniorrs","prdDesc":"Dry Food 200gm","prdPrice":402,"imgCode":3,"catCode":2},{"prdCode":4,"prdName":"Royal Canin Baby Dog Milk ","prdDesc":"Canned Food 200gm","prdPrice":342,"imgCode":1,"catCode":4}]
========================================================================
						References Resources
========================================================================
------------------------------------------------------------------------
Angular JS:
------------------------------------------------------------------------
http://angularjs4u.com/tables/top-10-angularjs-table-demos/

https://lostechies.com/gabrielschenker/2013/12/17/angularjspart-5-pushing-data-to-the-server/


http://www.codeproject.com/KB/scripting/753183/codebase.zip
Sign Up rani.x.velu@gmail.com/welcome
------------------------------------------------------------------------
Spring MVC 4
------------------------------------------------------------------------
Spring MVC Tiles Example			http://www.javatpoint.com/spring-mvc-tiles-example

------------------------------------------------------------------------
Derby Server
------------------------------------------------------------------------


------------------------------------------------------------------------
Hibernate
------------------------------------------------------------------------
