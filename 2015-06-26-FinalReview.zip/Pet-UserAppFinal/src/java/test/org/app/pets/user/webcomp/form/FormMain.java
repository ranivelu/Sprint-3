package org.app.pets.user.webcomp.form;

import java.util.ArrayList;
import java.util.List;

import org.app.pet.service.model.Product;

public class FormMain {
	
	static List<Product> list;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PetsForm<Product> pform = new PetsForm<Product>();
		if(pform.getPformList() == null){
			 list = new ArrayList<Product>();
		}
		
		pform.setPformList(list);
		/*if (pform.getPformList() != null) {
			Iterator<Product> itr = pform.getPformList().iterator();
			
			while (itr.hasNext()) {
				Product prd = itr.next();
				System.out.println(" : "+prd.getPrdCode());
			}
		}*/		
	}

}
