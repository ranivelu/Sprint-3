package org.app.pets.user.webcomp;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.app.pets.user.rest.api.UserUtil;
import org.app.pets.user.webcomp.form.OrderForm;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

/**
 * History, to view orders & details list
 * @author ravelu
 *
 */
@Controller
public class HistoryController {
	
	Log log = LogFactory.getLog(this.getClass());
	
	@RequestMapping("/history")
	public ModelAndView viewHistory() {
		log.info("["+this.getClass()+"]"+": viewHistory >>");
		ModelAndView mv = new ModelAndView("history");
		return mv;
	}
	
	
	@RequestMapping("/orders")
	public ModelAndView ordersList(HttpSession session) {
		log.info("["+this.getClass()+"]"+": viewHistory >>");
		
		List<OrderForm> olist = new ArrayList<OrderForm>();
		
		long sId = PetsCommon.getUserCode(session);
		String uMessage = UserUtil.S_BLANK;
		if(sId == 0) {
			uMessage = UserUtil.U_LOGIN;
		} 
		else  if(sId == -1 ){
			uMessage = UserUtil.U_INVALID_USERCODE;
		} else {
			/*Users users = PetsUtil.getUserById(sId);
			
			List<Object> ordList = PetsUtil.getOrdersByUserId(users.getUsrCode());
			
			Iterator<Object> itr = ordList.iterator();
			
			while (itr.hasNext()) {
				Orders ord = (Orders) itr.next();
				if (ord != null) {
					
					OrderForm oform = new OrderForm();
					oform.setOrdCode(ord.getOrdCode());
					oform.setOrdPrice(ord.getOrdPrice());
					oform.setCreatedOn(ord.getCreatedOn());
					oform.setModifiedOn(ord.getModifiedOn());
					oform.setCreatedBy(users.getUsrName());
					oform.setModifiedBy(users.getUsrName());
					
					
					List<Object> oiList = PetsUtil.getOrderItemsByOrder(users.getUsrCode());
					
					
					Iterator<Object> oiItr = oiList.iterator();
					
					while (oiItr.hasNext()) {
						OrderItem oi = (OrderItem) oiItr.next();
						if (oi != null) {
							
						}
					}
				}
			}*/
		}
		log.debug("["+this.getClass()+"]"+" Message : "+uMessage+" sId : "+sId);
		
		ModelAndView mv = new ModelAndView("orders");
		mv.addObject("orders", olist);
		mv.addObject("message", uMessage);
		
		return mv;
	}
	

}
