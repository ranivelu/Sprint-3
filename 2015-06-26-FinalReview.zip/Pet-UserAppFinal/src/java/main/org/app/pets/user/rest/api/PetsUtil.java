package org.app.pets.user.rest.api;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.app.pet.service.model.OrderItem;
import org.app.pet.service.model.Orders;
import org.app.pet.service.model.Product;
import org.app.pet.service.model.Users;
import org.app.pets.user.webcomp.form.UserForm;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.AnnotationIntrospector;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector;

/**
 * Rest Client
 * @author ravelu
 *
 * Parses JSON Rest Api call to Objects.
 */
public class PetsUtil {
	
	public static Log log = LogFactory.getLog(PetsUtil.class);
	
	/**
	 * Get Product By Id
	 * @param pCode
	 * @return
	 */
	public static List<Object> getOrdersByUserId(long pCode) {

		List<Object> ord = null;
		RestTemplate restTemplate = new RestTemplate();		 
		String urlPath = UserUtil.SERVER_URI + UserUtil.REST_G_HISTORY + pCode;

		String ordJson = restTemplate.getForObject(urlPath , String.class);
		log.debug(ordJson);
		 
		 
		ObjectMapper objectMapper = new ObjectMapper();
		
		AnnotationIntrospector introspector = new JacksonAnnotationIntrospector();
		objectMapper.getDeserializationConfig().with(introspector);
		objectMapper.getSerializationConfig().with(introspector);
	    
		try {
			JavaType type = objectMapper.getTypeFactory().constructCollectionType(ArrayList.class, Object.class);
			ord = objectMapper.readValue(ordJson, type);
		} catch (JsonParseException e) {			
			e.printStackTrace();
		} catch (JsonMappingException e) {			
			e.printStackTrace();
		} catch (IOException e) {			
			e.printStackTrace();
		}
		return ord;
	}
	
	
	/**
	 * Get Order Items By Order Id
	 * @param pCode
	 * @return
	 */
	public static List<Object> getOrderItemsByOrder(long oCode) {

		List<Object> oi = null;
		RestTemplate restTemplate = new RestTemplate();		 
		String urlPath = UserUtil.SERVER_URI + UserUtil.REST_G_HISTORY_ITEM + oCode;

		String oiJson = restTemplate.getForObject(urlPath , String.class);
		log.debug(oiJson);
		 
		ObjectMapper objectMapper = new ObjectMapper();
		
		AnnotationIntrospector introspector = new JacksonAnnotationIntrospector();
		objectMapper.getDeserializationConfig().with(introspector);
		objectMapper.getSerializationConfig().with(introspector);
	    
		try {
			JavaType type = objectMapper.getTypeFactory().constructCollectionType(ArrayList.class, Object.class);
			oi = objectMapper.readValue(oiJson, type);
		} catch (JsonParseException e) {			
			e.printStackTrace();
		} catch (JsonMappingException e) {			
			e.printStackTrace();
		} catch (IOException e) {			
			e.printStackTrace();
		}
		return oi;
	}
	
	
	/**
	 * Get Product By Id
	 * @param pCode
	 * @return
	 */
	public static Product getProductById(long pCode) {

		Product prd = null;
		RestTemplate restTemplate = new RestTemplate();		 
		String urlPath = UserUtil.SERVER_URI + UserUtil.REST_PRD_ID + pCode;

		String prdJson = restTemplate.getForObject(urlPath , String.class);
		log.debug(prdJson);
		 
		ObjectMapper objectMapper = new ObjectMapper();
	    
		try {
			prd = objectMapper.readValue(prdJson, Product.class);
			log.debug("Prd ID="+ prd.getPrdCode() +", Prd Name="+ prd.getPrdName() +", Prd Desc ="+ prd.getPrdDesc());
		} catch (JsonParseException e) {			
			e.printStackTrace();
		} catch (JsonMappingException e) {			
			e.printStackTrace();
		} catch (IOException e) {			
			e.printStackTrace();
		}
		return prd;
	}
	
	/**
	 * Get User by Id
	 * @param uCode
	 * @return
	 */
	public static UserForm getUserFormById(long uCode) {
		
		Users user = getUserById(uCode);
		UserForm uform = convertToUserForm(user);
		return uform;
	}
	
	/**
	 * Get User by Id
	 * @param uCode
	 * @return
	 */
	public static Users getUserById(long uCode) {

		Users usr = null;
		RestTemplate restTemplate = new RestTemplate();		 
		String urlPath = UserUtil.SERVER_URI + UserUtil.REST_USR_ID + uCode;

		String usrJson = restTemplate.getForObject(urlPath , String.class);
		log.debug(usrJson);
		 
		ObjectMapper objectMapper = new ObjectMapper();
	    
		try {
			usr = objectMapper.readValue(usrJson, Users.class);
			log.debug("Usr ID="+ usr.getUsrCode() +", Usr Name="+ usr.getUsrName() +", Usr Alias ="+ usr.getUsrAlias());
			log.debug("Usr ID="+ usr.getUsrCode() +", Usr Name="+ usr.getUsrName() +", Usr Alias ="+ usr.getUsrAlias());
		} catch (JsonParseException e) {			
			e.printStackTrace();
		} catch (JsonMappingException e) {			
			e.printStackTrace();
		} catch (IOException e) {			
			e.printStackTrace();
		}
		return usr;
	}
	
	/**
	 * Convert to Entity
	 * @param uform
	 * @return
	 */
	public static Users convertToUsers(UserForm uform) {
		Users user = new Users();
		user.setUsrCode(uform.getUsrCode());
    	user.setUsrAddress(uform.getUsrAddress());
    	user.setUsrEmail(uform.getUsrEmail());
    	user.setUsrMobile(uform.getUsrMobile());
    	user.setUsrName(uform.getUsrName());
    	user.setUsrAlias(uform.getUsrAlias());
    	user.setUsrPwd(uform.getUsrPwd());
    	user.setUsrType(uform.getUsrType());
    	
    	return user;
	}
	
	/**
	 * Convert to Form
	 * @param user
	 * @return
	 */
	public static UserForm convertToUserForm(Users user) {
		UserForm uform = new UserForm();
		uform.setUsrCode(user.getUsrCode());
		uform.setUsrAddress(user.getUsrAddress());
		uform.setUsrEmail(user.getUsrEmail());
		uform.setUsrMobile(user.getUsrMobile());
    	uform.setUsrName(user.getUsrName());
    	uform.setUsrAlias(user.getUsrAlias());
    	uform.setUsrPwd(user.getUsrPwd());
    	uform.setUsrType(user.getUsrType());
    	
    	return uform;
	}
	
	
	
	/**
	 * Create User
	 * @param user
	 * @return
	 */
	public static Users createUser(UserForm uform) {
		
		Users user = convertToUsers(uform);
		RestTemplate restTemplate = new RestTemplate();		 
		String urlPath = UserUtil.SERVER_URI + UserUtil.REST_C_USERS;

		ResponseEntity<Users> userRes = restTemplate.postForEntity(urlPath , user, Users.class);
		log.debug(userRes.getBody().getUsrAlias()+ " ; "+userRes.getBody().getUsrCode() );
		
		return userRes.getBody();
	}
	
	/**
	 * Create User
	 * @param user
	 * @return
	 */
	public static Users updateUser(UserForm uform) {
		
		Users user = convertToUsers(uform);
		
		RestTemplate restTemplate = new RestTemplate();		 
		String urlPath = UserUtil.SERVER_URI + UserUtil.REST_U_USERS;
		HttpEntity<Users> entity = new HttpEntity<Users>(user);
		
		ResponseEntity<Users> userRes = restTemplate.exchange(urlPath, HttpMethod.PUT, entity, Users.class);
		log.debug(userRes.getBody().getUsrAlias()+ " ; "+userRes.getBody().getUsrCode() );
		
		return userRes.getBody();
	}

	/**
	 * Create Order
	 * @param order
	 * @return
	 */
	public static Orders createOrders(Orders order) {
		
		RestTemplate restTemplate = new RestTemplate();		 
		String urlPath = UserUtil.SERVER_URI + UserUtil.REST_C_ORDERS;

		ResponseEntity<Orders> ordRes = restTemplate.postForEntity(urlPath , order, Orders.class);
		log.debug(ordRes.getBody().getOrdCode()+ " ; "+ordRes.getBody().getCreatedOn() );
		
		return ordRes.getBody();
	}
	
	/**
	 * Create Order Item
	 * @param order
	 * @return
	 */
	public static OrderItem createOrderItem(OrderItem oItem) {
		
		RestTemplate restTemplate = new RestTemplate();		 
		String urlPath = UserUtil.SERVER_URI + UserUtil.REST_C_ORDERITEM;

		ResponseEntity<OrderItem> ordRes = restTemplate.postForEntity(urlPath , oItem, OrderItem.class);
		log.debug(ordRes.getBody().getOrdCode()+ " ; "+ordRes.getBody().getCreatedOn() );
		
		return ordRes.getBody();
	}
}
