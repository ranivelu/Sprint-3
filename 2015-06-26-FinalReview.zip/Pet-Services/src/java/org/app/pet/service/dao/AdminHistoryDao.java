package org.app.pet.service.dao;

import javax.transaction.Transactional;

import org.app.pet.service.model.AdminHistory;

/**
 * Admin History Dao
 * @author ravelu
 *
 */
@Transactional
public class AdminHistoryDao extends AbsHibernateDao<AdminHistory> implements IAdminHistoryDao{
	
	public AdminHistoryDao() {
		super();
		setClassT(AdminHistory.class);
	}
}
