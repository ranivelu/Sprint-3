package org.app.pet.service.json;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.app.pet.service.dao.IOrderItemDao;
import org.app.pet.service.dao.IOrdersDao;
import org.app.pet.service.model.OrderItem;
import org.app.pet.service.model.Orders;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HistoryService {
	
	Log logger = LogFactory.getLog(this.getClass());
	
	//@Autowired
	private IOrderItemDao iOrderItemDao;

	//@Autowired
	private IOrdersDao iOrdersDao;
	
	/**
	 * Order Service instance bean loading
	 */
	public HistoryService(){
		super();		
		if(iOrderItemDao == null) {
			iOrderItemDao = PetShopUtil.getContext().getBean(IOrderItemDao.class);
		}		
		if(iOrdersDao == null) {
			iOrdersDao = PetShopUtil.getContext().getBean(IOrdersDao.class);
		}
	}
	 
	
	/**
	 * Get Order by User Id
	 * @param ordId
	 * @return
	 */
    @RequestMapping(value = "/rest/history/{id}", method = RequestMethod.GET)
    public @ResponseBody List<Object> getHistoryByUser(@PathVariable("id") String id) {
    	logger.debug("getHistoryByUser >> "+id);         
        return iOrdersDao.findListByColumns(Orders.PK_USR_CODE, id);
    }
	
	/**
     * Get OrderItem by Order Code 
     * @param ordItmId
     * @return
     */
    @RequestMapping(value = "/rest/history/orderitem/{id}", method = RequestMethod.GET)
    public @ResponseBody List<Object> getHistoryByOrderCode(@PathVariable("id") String ordId) {
    	logger.debug("getHistoryByOrderCode >> "+ ordId);         
        return iOrderItemDao.findListByColumns(OrderItem.PK_ORD_CODE, ordId);
    }

}
