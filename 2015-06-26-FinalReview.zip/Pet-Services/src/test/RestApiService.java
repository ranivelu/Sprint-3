import java.io.IOException;
import java.util.Date;

import org.app.pet.service.model.OrderItem;
import org.app.pet.service.model.Orders;
import org.app.pet.service.model.Product;
import org.app.pet.service.model.Users;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;



public class RestApiService {
	
	public static String SERVER_URI = "http://localhost:8080/petuser";
    
    public static void main(String args[]){
         
        //testProduct();
     //   System.out.println(" >> ");
        
        //testCategories();
      //  System.out.println(" >> ");
        
      //  testUsers();
       // System.out.println(" >> "); guest ; 2
        
        testOrders();
        System.out.println(" >> ");
        
    }
 
    private static void testOrders() {
		
    	
    	String REST_C_ORDERS =  "/rest/order/create";
    	
    	RestTemplate restTemplate = new RestTemplate();		 
		String urlPath = SERVER_URI + REST_C_ORDERS;
		
		
		Orders ord = new Orders();
		ord.setUsrCode(1);
		ord.setCreatedBy(1);
		ord.setModifiedBy(1);
		ord.setCreatedOn(new Date());
		ord.setModifiedOn(new Date());
		ord.setOrdPrice(10);
		
	
		ResponseEntity<Orders> res = restTemplate.postForEntity(urlPath , ord, Orders.class);		
		System.out.println(res.getBody().getUsrCode() + " ; "+res.getBody().getOrdCode() );
		//[1:Royal Canin Baby Dog Milk]: [342]: [1]
		
		
		OrderItem oi = new OrderItem();
		oi.setItmName("1:Royal Canin Baby Dog Milk");
		oi.setItmPrice(342);
		oi.setItmQuantity(1);
		oi.setCreatedBy(1);
		oi.setModifiedBy(1);
		oi.setCreatedOn(new Date());
		oi.setModifiedOn(new Date());
		oi.setOrdCode(1); //res.getBody().getOrdCode());
		
		String REST_C_ORDERITEM =  "/rest/orderitem/create";
		
		RestTemplate restTemplate1 = new RestTemplate();		 
		String urlPath1 = SERVER_URI + REST_C_ORDERITEM;

		ResponseEntity<OrderItem> oiRes = restTemplate1.postForEntity(urlPath1 , oi, OrderItem.class);
		System.out.println(oiRes.getBody().getItmCode() + " ; "+oiRes.getBody().getOrdCode() );
		
	}

	private static void testUsers() {
    	
    	String REST_C_USERS =  "/rest/user/create";
    	
    	Users user = new Users();
    	user.setUsrAddress("PSN");
    	user.setUsrEmail("guest@pet.com");
    	user.setUsrMobile(00);
    	user.setUsrName("Guest");
    	user.setUsrAlias("guest");
    	user.setUsrPwd("guest");
    	user.setUsrType("C");
    	
    	
    	RestTemplate restTemplate = new RestTemplate();		 
		String urlPath = SERVER_URI + REST_C_USERS;

		ResponseEntity<Users> userRes = restTemplate.postForEntity(urlPath , user, Users.class);		
		System.out.println(userRes.getBody().getUsrAlias()+ " ; "+userRes.getBody().getUsrCode() );
		
	}

	private static void testCategories() {
		// TODO Auto-generated method stub
		
	}

	private static void testProduct() {

		 RestTemplate restTemplate = new RestTemplate();
		 
		 //objectMapper.readValue(json, SearchRequest.class);
		 String url = SERVER_URI + "/rest/product/1";
		 
		String prdJson = restTemplate.getForObject(url, String.class);
		 System.out.println(prdJson);
		 
		ObjectMapper objectMapper = new ObjectMapper();
	    Product prd;
		try {
			prd = objectMapper.readValue(prdJson, Product.class);
			 System.out.println("Prd ID="+ prd.getPrdCode() +", Prd Name="+ prd.getPrdName() +", Prd Desc ="+ prd.getPrdDesc());
		} catch (JsonParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	         
	    //    System.out.println("Employee Object\n"+emp);
	     
	    
	}

	
 
   /* private static void testCreateEmployee() {
        RestTemplate restTemplate = new RestTemplate();
        Employee emp = new Employee();
        emp.setId(1);emp.setName("Pankaj Kumar");
        Employee response = restTemplate.postForObject(SERVER_URI+EmpRestURIConstants.CREATE_EMP, emp, Employee.class);
        printEmpData(response);
    }*/
 
   
}