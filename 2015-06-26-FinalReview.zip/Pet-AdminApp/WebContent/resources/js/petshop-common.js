/*
 * @author : ravelu
 * @date   : 2015-06-11
 * This is an common script library across pet shop applications. 
 */

//All REST URLS

var urlPath=window.location.pathname;
var urlPathArray = urlPath.split('/');	
var appRoot = window.location.origin + "/" + urlPathArray[1];

var REST_AUTHENTICATE_USER  = appRoot + '/rest/authenticate';

var REST_GET_CAT =  appRoot + "/rest/categories";

var REST_GET_CAT_DETAILS =  appRoot + "/rest/category/" ;

var REST_GET_ORDERS =  appRoot + "/rest/orders"; 

var REST_GET_PRD_DETAILS = appRoot + "/rest/product/";

var REST_GET_PRODUCTS = appRoot + "/rest/products"; 

//Admin related API
var REST_GET_IMAGES =  appRoot + "/rest/images";
var REST_GET_USERS =  appRoot + "/rest/users";

/**
 * Split Url
 * @param index
 * @returns
 */
function spiltUrl(index){
	urlPath=window.location.pathname;
	urlPathArray = urlPath.split('/'); 	
	return urlPathArray[index];
}

/**
 * Product Details Url with Code
 * @returns {String}
 */
function getProductDetailsUrl() {
	return REST_GET_PRD_DETAILS + spiltUrl(3);
}

/**
 * Category Details Url with Code
 * @returns {String}
 */
function getCategoryDetailsUrl() {
	return REST_GET_CAT_DETAILS + spiltUrl(3);
}