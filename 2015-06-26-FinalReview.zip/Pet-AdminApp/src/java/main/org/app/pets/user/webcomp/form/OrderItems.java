package org.app.pets.user.webcomp.form;

/**
 * @author ravelu
 * Order Item, form to handle ordered item details.
 */

public class OrderItems {
	
	public OrderItems(){
		
	}
	
	public OrderItems(String itmName, long itmQuantity, long itmPrice) {
		super();
		this.itmName = itmName;
		this.itmQuantity = itmQuantity;
		this.itmPrice = itmPrice;
	}

	public String itmName;
	
	public long itmQuantity;
	
	public long itmPrice;

	public String getItmName() {
		return itmName;
	}

	public void setItmName(String itmName) {
		this.itmName = itmName;
	}

	public long getItmQuantity() {
		return itmQuantity;
	}

	public void setItmQuantity(long itmQuantity) {
		this.itmQuantity = itmQuantity;
	}

	public long getItmPrice() {
		return itmPrice;
	}

	public void setItmPrice(long itmPrice) {
		this.itmPrice = itmPrice;
	}
}
