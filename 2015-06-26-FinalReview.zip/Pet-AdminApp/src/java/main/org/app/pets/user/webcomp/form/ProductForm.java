package org.app.pets.user.webcomp.form;

/**
 * Product Form
 * @author ravelu
 *
 */
public class ProductForm {
	
	public long prdCode;
	
	public String prdName;
	
	public String prdDesc;
	
	public long prdPrice;
	
	public long imgCode;

	public long catCode;

	public long getPrdCode() {
		return prdCode;
	}

	public void setPrdCode(long prdCode) {
		this.prdCode = prdCode;
	}

	public String getPrdName() {
		return prdName;
	}

	public void setPrdName(String prdName) {
		this.prdName = prdName;
	}

	public String getPrdDesc() {
		return prdDesc;
	}

	public void setPrdDesc(String prdDesc) {
		this.prdDesc = prdDesc;
	}

	public long getPrdPrice() {
		return prdPrice;
	}

	public void setPrdPrice(long prdPrice) {
		this.prdPrice = prdPrice;
	}

	public long getImgCode() {
		return imgCode;
	}

	public void setImgCode(long imgCode) {
		this.imgCode = imgCode;
	}

	public long getCatCode() {
		return catCode;
	}

	public void setCatCode(long catCode) {
		this.catCode = catCode;
	}
}
