package org.app.pets.user.webcomp.form;

import java.util.List;

/**
 * This is an Generic Form
 * @author ravelu
 *
 * @param <T>
 */
public class PetsForm<T> {
	
	
	private List<T> pformList;

	public List<T> getPformList() {
		return pformList;
	}

	public void setPformList(List<T> arrayList) {
		this.pformList = arrayList;
	}
}
