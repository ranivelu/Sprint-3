package org.app.pets.user.webcomp.form;


/**
 * Category Form
 * @author ravelu
 *
 */
public class CategoryForm {
	
	public long catCode;
	
	public String catName;
	
	public String catDesc;
	
	public long catChildCode;
	
	public long imgCode;

	public long getCatCode() {
		return catCode;
	}

	public void setCatCode(long catCode) {
		this.catCode = catCode;
	}

	public String getCatName() {
		return catName;
	}

	public void setCatName(String catName) {
		this.catName = catName;
	}

	public String getCatDesc() {
		return catDesc;
	}

	public void setCatDesc(String catDesc) {
		this.catDesc = catDesc;
	}

	public long getCatChildCode() {
		return catChildCode;
	}

	public void setCatChildCode(long catChildCode) {
		this.catChildCode = catChildCode;
	}

	public long getImgCode() {
		return imgCode;
	}

	public void setImgCode(long imgCode) {
		this.imgCode = imgCode;
	}
}
