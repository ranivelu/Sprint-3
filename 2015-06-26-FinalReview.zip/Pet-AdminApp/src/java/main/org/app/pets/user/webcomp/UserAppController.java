package org.app.pets.user.webcomp;

import javax.servlet.http.HttpSession;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.app.pet.service.model.Users;
import org.app.pets.user.rest.api.PetsUtil;
import org.app.pets.user.rest.api.ConstUtil;
import org.app.pets.user.webcomp.form.UserForm;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;
/**
 * Spring Controller
 * @author ravelu
 *
 * This is used for request handling related to user.
 */
@Controller
@SessionAttributes("name")
public class UserAppController {
	String message = "Welcome to User Module(Pet Shop Application)!";
	
	Log log = LogFactory.getLog(this.getClass());
 
	/**
	 * Welcome Page
	 * @param name
	 * @param id
	 * @param session
	 * @return
	 */
	@RequestMapping("/welcome")
	public ModelAndView showMessage(
			@RequestParam(value = "name", required = false, defaultValue = "Guest") String name, 
			@RequestParam(value = "id", required = false, defaultValue = "0") String id,
			@RequestParam(value = "type", required = false, defaultValue = "0") String type, //Admin
			HttpSession session) {
		
		/*WebApplicationContext applicationContext = WebApplicationContextUtils.getWebApplicationContext(
				 getServletContext());
		*/
		log.info("["+this.getClass()+"]"+": showMessage >>");
		ModelAndView mv = new ModelAndView("welcome");
		mv.addObject("message", message);
		mv.addObject("name", name);
		mv.addObject("id", id);
		session.setAttribute("id", id);		
		session.setAttribute("type", type); //Admin
		return mv;
	}
	
	/**
	 * User Create
	 * @param uform
	 * @param session
	 * @return
	 */
	@RequestMapping("/create")
	public ModelAndView createUser(@ModelAttribute("user") UserForm uform, HttpSession session) {
		log.info("["+this.getClass()+"]"+": registerUser >>");
		log.debug("[" + this.getClass() + "]" + ": registerUser >> "
				+"; "+uform.getUsrAlias()
				+"; "+uform.getUsrEmail()
				+"; "+uform.getUsrMobile()
				+"; "+uform.getUsrName()
				+"; "+uform.getUsrPwd()
				+"; "+uform.getUsrType());
		
		if(uform != null) {
			Users cuser = PetsUtil.createUser(uform);
			log.debug(" ID : " + cuser.getUsrAlias() + " " + cuser.getUsrCode());
			uform.setUsrCode(cuser.getUsrCode());
		}
		ModelAndView mv = new ModelAndView("profile");
		mv.addObject("user", uform);
		return mv;
	}
	
	/**
	 * User Update
	 * @param uform
	 * @param session
	 * @return
	 */
	@RequestMapping("/update")
	public ModelAndView updateUser(@ModelAttribute("user") UserForm uform, HttpSession session) {
		log.info("["+this.getClass()+"]"+": updateUser >>");
		log.debug("[" + this.getClass() + "]" + ": updateUser >> "
				+"; "+uform.getUsrAlias()
				+"; "+uform.getUsrEmail()
				+"; "+uform.getUsrMobile()
				+"; "+uform.getUsrName()
				+"; "+uform.getUsrPwd()
				+"; "+uform.getUsrType());
		
		String uMessage = ConstUtil.S_BLANK;
		if(uform != null) {
			Users cuser = PetsUtil.updateUser(uform);
			uform = PetsUtil.convertToUserForm(cuser);
			log.debug(" ID : " + cuser.getUsrAlias() + " " + cuser.getUsrCode());
			uform.setUsrCode(cuser.getUsrCode());
		} 
		
		ModelAndView mv = new ModelAndView("profile");
		mv.addObject("user", uform);
		mv.addObject("message", uMessage);
		return mv;
	}
	
	/**
	 * User Profile View
	 * @param usrCode
	 * @param session
	 * @return
	 */
	@RequestMapping("/profile/{usrCode}")
	public ModelAndView getUserProfile(@PathVariable("usrCode") long usrCode, HttpSession session) {		
		log.info("["+this.getClass()+"]"+": getUserProfile >>");
		UserForm uform = null;
		long sId = PetsCommon.getUserCode(session);
		String uMessage = ConstUtil.S_BLANK;
		if(sId == 0) {
			uMessage = ConstUtil.U_LOGIN;
		}
		else if(sId != usrCode) {
			uMessage = ConstUtil.U_INVALID_USER + usrCode;
		} 
		else  if(sId == -1 || usrCode <= 0){
			uMessage = ConstUtil.U_INVALID_USERCODE;
		} else {
			uform = PetsUtil.getUserFormById(sId);
			log.debug(" Profile Detasls : " + uform.getUsrAlias() + " " + uform.getUsrCode());
		}
		log.debug("["+this.getClass()+"]"+" Message : "+uMessage+" sId : "+sId);
			
		ModelAndView mv = new ModelAndView("profile");	
		mv.addObject("user", uform);
		mv.addObject("message", uMessage);
		return mv;
	}
	
	/**
	 * Register Page
	 * @return
	 */
	@RequestMapping("/register")
	public ModelAndView registerUser() {
		log.info("["+this.getClass()+"]"+": registerUser >>");
		ModelAndView mv = new ModelAndView("register");
		return mv;
	}
	
	/**
	 * Login Page
	 * @return
	 */
	@RequestMapping("/login")
	public ModelAndView userLogin() {
		log.info("["+this.getClass()+"]"+": userLogin >>");
		ModelAndView mv = new ModelAndView("login");
		return mv;
	}
	
	/**
	 * Sprint Future Deliverable
	 * @return
	 */
	@RequestMapping("/tbd")
	public ModelAndView toBeDone() {
		log.info("["+this.getClass()+"]"+": toBeDone >>");
		ModelAndView mv = new ModelAndView("tbd");
		mv.addObject("message", "Page Under Construction");
		mv.addObject("tdb_name", ": Future Sprints !");
		return mv;
	}
}