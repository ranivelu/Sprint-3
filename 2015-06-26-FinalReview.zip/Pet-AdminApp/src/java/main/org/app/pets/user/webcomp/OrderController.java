package org.app.pets.user.webcomp;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.app.pet.service.model.OrderItem;
import org.app.pet.service.model.Orders;
import org.app.pet.service.model.Product;
import org.app.pets.user.rest.api.PetsUtil;
import org.app.pets.user.rest.api.ConstUtil;
import org.app.pets.user.webcomp.form.OrderItemForm;
import org.app.pets.user.webcomp.form.OrderItems;
import org.app.pets.user.webcomp.form.PetsForm;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

/**
 * Spring Controller
 * 
 * @author ravelu
 * 
 *         This is used for request handling related to 'Add to Cart'.
 */
@Controller
@SessionAttributes("productInCart")
public class OrderController {

	Log log = LogFactory.getLog(this.getClass());
	
	
	/**
	 * Add Product to Cart
	 * 
	 * @param pCode
	 * @param session
	 * @return
	 */
	@RequestMapping("/paddcart/{prdCode}")
	public ModelAndView productAddtoCart(@PathVariable("prdCode") long pCode,
			HttpSession session) {
		log.info("[" + this.getClass() + "]" + ": productAddtoCart >>");
		log.debug("[" + this.getClass() + "]" + ": productAddtoCart >>");
		
		PetsForm<Product> pform = new PetsForm<Product>();
		pform.setPformList(getPSessionAttribute(session, "productInCart"));
		
		if (pform.getPformList() == null) {
			pform.setPformList(new ArrayList<Product>());
		}
		if(pCode > 0) {
			Product prd = PetsUtil.getProductById(pCode);
			if (prd != null) {
				//Check for Duplicates
				boolean found = false;				
				Iterator<Product> itr = pform.getPformList().iterator();
				
				while (itr.hasNext()) {
					Product iprd = itr.next();
					if (iprd.getPrdCode() == pCode) {
						found = true;
					}
				}
				//Add, if not exist
				if(!found) {
					pform.getPformList().add(prd);	
				}
			}
			session.setAttribute("productInCart",  pform.getPformList());
		}
		ModelAndView mv = new ModelAndView("vcart");
		mv.addObject("listProducts", pform);
		return mv;
	}

	/**
	 * Get Product from Session
	 * @param session
	 * @param id
	 * @return
	 */
	@SuppressWarnings("unchecked")
	private ArrayList<Product> getPSessionAttribute(HttpSession session, String id) {
		return (ArrayList<Product>) session.getAttribute(id);
	}

	/**
	 * Delete from Cart
	 * 
	 * @param pCode
	 * @param session
	 * @return
	 */
	@RequestMapping("/pdelcart/{prdCode}")
	public ModelAndView productDelFromCart(@PathVariable("prdCode") long pCode,
			HttpSession session) {
		log.info("[" + this.getClass() + "]" + ": productDelFromCart >>");
		log.debug("[" + this.getClass() + "]" + ": productDelFromCart >> " +pCode);		
		
		PetsForm<Product> pform = new PetsForm<Product>();
		pform.setPformList(getPSessionAttribute(session, "productInCart"));
		
		if (pform.getPformList() != null) {
			Iterator<Product> itr = pform.getPformList().iterator();
			
			while (itr.hasNext()) {
				Product prd = itr.next();
				if (prd.getPrdCode() == pCode) {
					itr.remove();
					log.debug("Removed : "+prd.getPrdCode());
				}
			}
		}
		session.setAttribute("productInCart",  pform.getPformList());

		ModelAndView mv = new ModelAndView("vcart");
		mv.addObject("listProducts", pform);
		return mv;
	}
	
	
	/**
	 * Select Product, generate Order Item
	 * 
	 * @param pCode
	 * @param session
	 * @return
	 */
	@RequestMapping("/pcart")
	public ModelAndView productToItem(HttpSession session) {
		log.info("[" + this.getClass() + "]" + ": productToItem >>");
		//log.debug("[" + this.getClass() + "]" + ": productToItem >>");
		
		OrderItemForm oform = new OrderItemForm();		
		PetsForm<Product> pform = new PetsForm<Product>();
		
		pform.setPformList(getPSessionAttribute(session, "productInCart"));
		if (pform.getPformList() != null) {
			
			List<OrderItems> oItems = new ArrayList<OrderItems>(); 
		
			Iterator<Product> itr = pform.getPformList().iterator();			
			log.debug("[" + this.getClass() + "]" + ": Product Size >>" + pform.getPformList().size());
			
			while (itr.hasNext()) {
				Product prd = itr.next();

				if (prd != null) {
					
					OrderItems oi = new OrderItems();
					oi.setItmName(prd.getPrdCode() + ":" +prd.getPrdName());
					log.debug("[" + this.getClass() + "]" + ":  oi.getItmName() >>" + oi.getItmName());
					oi.setItmPrice(prd.getPrdPrice());
					oi.setItmQuantity(1); //default to 1
					oItems.add(oi);
				}
			}
			
			oform.setOrderItems(oItems);
		}
		
		session.setAttribute("orderItems", oform);
		return new ModelAndView("pcart" , "listItems", oform);
	}


	/**
	 * Place Order with Order Items
	 * 
	 * @param session
	 * @return
	 */
	@RequestMapping(value = "/pOrder", method = RequestMethod.POST)
	public ModelAndView placeOrder(@ModelAttribute("listItems") OrderItemForm oform, HttpSession session) {
		log.info("[" + this.getClass() + "]" + ": placeOrder >>");
		log.debug("[" + this.getClass() + "]" + ": placeOrder >> " +oform );
		long ordPrice = 0;
		String orderId = "XXXX";	
		
		if (oform != null ) {
			
			if(oform.getOrderItems() != null ) {
			
				Iterator<OrderItems> itr = oform.getOrderItems().iterator();
				//Compute Total Price
				while (itr.hasNext()) {
					OrderItems oi = itr.next();
	
					if (oi != null) {
						log.debug("[" + oi.getItmName() + "]" + ": [" + oi.getItmPrice() + "]" + ": [" + oi.getItmQuantity() +"]");
						ordPrice += (oi.getItmPrice() * oi.getItmQuantity());
					}
				}
			
				long usrCode = PetsCommon.getUserCode(session);
				
				Orders ord = new Orders();
				ord.setUsrCode(usrCode);
				ord.setCreatedBy(usrCode);
				ord.setModifiedBy(usrCode);
				ord.setCreatedOn(new Date());
				ord.setModifiedOn(new Date());
				ord.setOrdPrice(ordPrice);
	
				Orders sOrder = PetsUtil.createOrders(ord);
				orderId = ConstUtil.S_BLANK + sOrder.getOrdCode();
				
				
				if(sOrder.getOrdCode() > 0) {
					//Create Items
					log.debug(" ID : " + sOrder.getOrdCode() + " " + sOrder.getUsrCode());
					itr = oform.getOrderItems().iterator();
					while (itr.hasNext()) {
						OrderItems oiform = itr.next();
	
						if (oiform != null) {
							
							OrderItem oi = new OrderItem();
							oi.setItmName(oiform.getItmName());
							oi.setItmPrice(oiform.getItmPrice());
							oi.setItmQuantity(oiform.getItmQuantity());
							oi.setCreatedBy(usrCode);
							oi.setModifiedBy(usrCode);
							oi.setCreatedOn(new Date());
							oi.setModifiedOn(new Date());
							oi.setOrdCode(sOrder.getOrdCode());
							
							OrderItem oItem = PetsUtil.createOrderItem(oi);
							log.debug(" ID : " + oItem.getItmCode() + " " + oItem.getOrdCode());
						}
					}	
				}
			}else {
				log.debug("[" + this.getClass() + "]" + ": placeOrder >> NULL LIST" );
			} 
		}else {
			log.debug("[" + this.getClass() + "]" + ": placeOrder >> NULL form" );
		}

		ModelAndView mv = new ModelAndView("porder");
		mv.addObject("orderId", orderId);

		return mv;
	}
}
