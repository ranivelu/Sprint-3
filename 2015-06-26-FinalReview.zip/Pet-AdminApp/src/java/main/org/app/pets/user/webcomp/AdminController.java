package org.app.pets.user.webcomp;

import javax.servlet.http.HttpSession;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.app.pet.service.model.Category;
import org.app.pet.service.model.Product;
import org.app.pet.service.model.Users;
import org.app.pets.user.rest.api.AdminUtil;
import org.app.pets.user.rest.api.PetsUtil;
import org.app.pets.user.webcomp.form.CategoryForm;
import org.app.pets.user.webcomp.form.ProductForm;
import org.app.pets.user.webcomp.form.UserForm;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class AdminController {
	
	Log log = LogFactory.getLog(this.getClass());
	
	/**
	 * Get Admin related Operation Access.
	 * @param prdCode
	 * @return
	 */
	@RequestMapping("/admin")
	public ModelAndView admin() {
		ModelAndView mv = new ModelAndView("admin");				
		return mv;
	}
	
	/**
	 * Get Admin - Add User View
	 * @param prdCode
	 * @return
	 */
	@RequestMapping("/imagelist")
	public ModelAndView imageList() {
		ModelAndView mv = new ModelAndView("imagelist");				
		return mv;
	}
	
	/**
	 * Get Admin - Add User View
	 * @param prdCode
	 * @return
	 */
	@RequestMapping("/orderlist")
	public ModelAndView orderList() {
		ModelAndView mv = new ModelAndView("orderlist");				
		return mv;
	}
	
	/**
	 * Get Admin - Add User View
	 * @param prdCode
	 * @return
	 */
	@RequestMapping("/userlist")
	public ModelAndView userList() {
		ModelAndView mv = new ModelAndView("userlist");				
		return mv;
	}
	
	
	/**
	 * Get Admin - Add User View
	 * @param prdCode
	 * @return
	 */
	@RequestMapping("/uadd")
	public ModelAndView uAdd() {
		ModelAndView mv = new ModelAndView("uadd");				
		return mv;
	}
	
	
	

	/**
	 * Get Admin - Add Product View
	 * @param prdCode
	 * @return
	 */
	@RequestMapping("/padd")
	public ModelAndView pAdd() {
		ModelAndView mv = new ModelAndView("padd");				
		return mv;
	}
	
	/**
	 * Get Admin - Add Category View
	 * @param prdCode
	 * @return
	 */
	@RequestMapping("/cadd")
	public ModelAndView cAdd() {
		ModelAndView mv = new ModelAndView("cadd");				
		return mv;
	}
	
	/**
	 * Get Admin - Add Order View
	 * @param prdCode
	 * @return
	 */
	@RequestMapping("/oadd")
	public ModelAndView oAdd() {
		ModelAndView mv = new ModelAndView("oadd");				
		return mv;
	}
	

	/**
	 * Get Admin - Add Image View
	 * @param prdCode
	 * @return
	 */
	@RequestMapping("/iadd")
	public ModelAndView iAdd() {
		ModelAndView mv = new ModelAndView("iadd");				
		return mv;
	}
	
	/**
	 * User Create
	 * @param uform
	 * @param session
	 * @return
	 */
	@RequestMapping("/createUser")
	public ModelAndView createUser(@ModelAttribute("user") UserForm uform, HttpSession session) {
		log.info("["+this.getClass()+"]"+": createUser >>");
		log.debug("[" + this.getClass() + "]" + ": createUser >> "
				+"; "+uform.getUsrAlias()
				+"; "+uform.getUsrEmail()
				+"; "+uform.getUsrMobile()
				+"; "+uform.getUsrName()
				+"; "+uform.getUsrPwd()
				+"; "+uform.getUsrType());
		
		if(uform != null) {
			Users cuser = PetsUtil.createUser(uform);
			log.debug(" ID : " + cuser.getUsrAlias() + " " + cuser.getUsrCode());
			uform.setUsrCode(cuser.getUsrCode());
		}
		ModelAndView mv = new ModelAndView("userlist");
		mv.addObject("user", uform);
		return mv;
	}
	
	/**
	 * User Create
	 * @param uform
	 * @param session
	 * @return
	 */
	@RequestMapping("/createCategory")
	public ModelAndView createCategory(@ModelAttribute("category") CategoryForm cform, HttpSession session) {
		log.info("["+this.getClass()+"]"+": createCategory >>");

		if(cform != null) {
			Category cat = AdminUtil.createCategory(cform);
			log.debug(" ID : " + cat.getCatCode());
			
		}
		ModelAndView mv = new ModelAndView("categorylist");
		return mv;
	}
	
	/**
	 * User Create
	 * @param uform
	 * @param session
	 * @return
	 */
	@RequestMapping("/createProduct")
	public ModelAndView createProduct(@ModelAttribute("product") ProductForm  pform, HttpSession session) {
		log.info("["+this.getClass()+"]"+": createProduct >>");

		if(pform != null) {
			Product product = AdminUtil.createProduct(pform);
			log.debug(" ID : " + product.getPrdCode());
		}
		ModelAndView mv = new ModelAndView("productlist");
		return mv;
	}

}
