package org.app.pets.user.webcomp;

import javax.servlet.http.HttpSession;
/**
 * This is an common Utility
 * @author ravelu
 *
 */
public class PetsCommon {
	
	/**
	 * Get Session UserCode
	 * @param session
	 * @return
	 */
	public static long getUserCode(HttpSession session)	{
		Object id = session.getAttribute("id");
		long usrCode = 0; // Guest User
		if (id != null) {
			try{
				usrCode = Integer.parseInt(id.toString());	
			} catch(Exception ex) {
				usrCode = -1;
			}
		}
		return usrCode;
	}

}
