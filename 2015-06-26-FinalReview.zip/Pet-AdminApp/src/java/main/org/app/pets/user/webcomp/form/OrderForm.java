package org.app.pets.user.webcomp.form;

import java.util.Date;
/**
 * Form Pojo's
 * @author ravelu
 *
 */
public class OrderForm {
	
	private OrderItemForm ordform;
	
	private long ordCode;
	
	private long ordPrice;
	
	private Date createdOn;
	
	private Date modifiedOn;
	
	private String createdBy;
	
	private String modifiedBy;

	public OrderItemForm getOrdform() {
		return ordform;
	}

	public void setOrdform(OrderItemForm ordform) {
		this.ordform = ordform;
	}

	public long getOrdCode() {
		return ordCode;
	}

	public void setOrdCode(long ordCode) {
		this.ordCode = ordCode;
	}

	public long getOrdPrice() {
		return ordPrice;
	}

	public void setOrdPrice(long ordPrice) {
		this.ordPrice = ordPrice;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public Date getModifiedOn() {
		return modifiedOn;
	}

	public void setModifiedOn(Date modifiedOn) {
		this.modifiedOn = modifiedOn;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
}
