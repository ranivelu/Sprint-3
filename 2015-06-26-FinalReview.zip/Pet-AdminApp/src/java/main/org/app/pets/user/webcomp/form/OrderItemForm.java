package org.app.pets.user.webcomp.form;

import java.util.List;

/**
 * @author ravelu
 * Order Item, form to handle ordered item details.
 */

public class OrderItemForm {
	
	private List<OrderItems> orderItems;

	public List<OrderItems> getOrderItems() {
		return orderItems;
	}

	public void setOrderItems(List<OrderItems> orderItems) {
		this.orderItems = orderItems;
	}
}
