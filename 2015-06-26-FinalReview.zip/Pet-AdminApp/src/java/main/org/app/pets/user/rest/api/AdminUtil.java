package org.app.pets.user.rest.api;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.app.pet.service.model.Category;
import org.app.pet.service.model.Product;
import org.app.pets.user.webcomp.form.CategoryForm;
import org.app.pets.user.webcomp.form.ProductForm;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

/**
 * All Utils & Constants (URI, String etc)
 * 
 * @author ravelu
 * 
 */
public class AdminUtil {

	public static Log log = LogFactory.getLog(PetsUtil.class);

	/**
	 * Create User
	 * 
	 * @param user
	 * @return
	 */
	public static Product createProduct(ProductForm pform) {

		Product product = convertToProduct(pform);
		RestTemplate restTemplate = new RestTemplate();
		String urlPath = ConstUtil.SERVER_URI + ConstUtil.REST_C_PRODUCT;

		ResponseEntity<Product> response = restTemplate.postForEntity(urlPath,
				product, Product.class);
		log.debug(PetsUtil.class + ": " +response.getBody().getPrdCode() + " ; "
				+ response.getBody().getPrdName());

		return response.getBody();
	}

	/**
	 * Create User
	 * 
	 * @param user
	 * @return
	 */
	public static Category createCategory(CategoryForm cform) {

		Category cat = convertToCat(cform);
		RestTemplate restTemplate = new RestTemplate();
		String urlPath = ConstUtil.SERVER_URI + ConstUtil.REST_C_CATEGORY;

		ResponseEntity<Category> response = restTemplate.postForEntity(urlPath,
				cat, Category.class);
		log.debug(response.getBody().getCatCode() + " ; "
				+ response.getBody().getCatName());
		
		return response.getBody();
	}

	/**
	 * Convert to Entity
	 * 
	 * @param pform
	 * @return
	 */
	public static Product convertToProduct(ProductForm pform) {
		Product product = new Product();
		product.setPrdCode(pform.getPrdCode());
		product.setCatCode(pform.getCatCode());
		product.setImgCode(pform.getImgCode());
		product.setPrdDesc(pform.getPrdDesc());
		product.setPrdName(pform.getPrdName());
		product.setPrdPrice(pform.getPrdPrice());
		return product;
	}

	/**
	 * Convert to Form
	 * 
	 * @param user
	 * @return
	 */
	public static ProductForm convertToProductForm(Product product) {
		ProductForm pform = new ProductForm();
		pform.setPrdCode(product.getPrdCode());
		pform.setCatCode(product.getCatCode());
		pform.setImgCode(product.getImgCode());
		pform.setPrdDesc(product.getPrdDesc());
		pform.setPrdName(product.getPrdName());
		pform.setPrdPrice(product.getPrdPrice());
		return pform;
	}

	/**
	 * Convert to Entity
	 * 
	 * @param cform
	 * @return
	 */
	public static Category convertToCat(CategoryForm cform) {
		Category cat = new Category();
		cat.setCatCode(cform.getCatCode());
		cat.setCatChildCode(cform.getCatChildCode());
		cat.setCatDesc(cform.getCatDesc());
		cat.setCatName(cform.getCatName());
		cat.setImgCode(cform.getImgCode());
		return cat;
	}

	/**
	 * Convert to Form
	 * 
	 * @param user
	 * @return
	 */
	public static CategoryForm convertToCatForm(Category cat) {
		CategoryForm cform = new CategoryForm();
		cform.setCatCode(cat.getCatCode());
		cform.setCatChildCode(cat.getCatChildCode());
		cform.setCatDesc(cat.getCatDesc());
		cform.setCatName(cat.getCatName());
		cform.setImgCode(cat.getImgCode());

		return cform;
	}
}
