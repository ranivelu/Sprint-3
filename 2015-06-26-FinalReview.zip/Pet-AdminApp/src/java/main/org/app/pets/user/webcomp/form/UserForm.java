package org.app.pets.user.webcomp.form;

/**
 * User Form for Registration
 * @author ravelu
 *
 */
public class UserForm{

	public long usrCode;
	
	public String usrName;
	
	public String usrPwd;
	
	public String usrAlias;
	
	public String usrType;
	
	public long usrMobile;
	
	public String usrEmail;
	
	public String usrAddress;

	public long getUsrCode() {
		return usrCode;
	}

	public void setUsrCode(long usrCode) {
		this.usrCode = usrCode;
	}

	public String getUsrName() {
		return usrName;
	}

	public void setUsrName(String usrName) {
		this.usrName = usrName;
	}

	public String getUsrPwd() {
		return usrPwd;
	}

	public void setUsrPwd(String usrPwd) {
		this.usrPwd = usrPwd;
	}

	public String getUsrAlias() {
		return usrAlias;
	}

	public void setUsrAlias(String usrAlias) {
		this.usrAlias = usrAlias;
	}

	public String getUsrType() {
		return usrType;
	}

	public void setUsrType(String usrType) {
		this.usrType = usrType;
	}

	public long getUsrMobile() {
		return usrMobile;
	}

	public void setUsrMobile(long usrMobile) {
		this.usrMobile = usrMobile;
	}

	public String getUsrEmail() {
		return usrEmail;
	}

	public void setUsrEmail(String usrEmail) {
		this.usrEmail = usrEmail;
	}

	public String getUsrAddress() {
		return usrAddress;
	}

	public void setUsrAddress(String usrAddress) {
		this.usrAddress = usrAddress;
	}
}
